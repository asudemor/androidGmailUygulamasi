package com.istinye.week7;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import static com.istinye.week7.R.id;
import static com.istinye.week7.R.layout;

public class DetailActivity extends AppCompatActivity {

    @SuppressLint("ResourceType")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(layout.activity_detail);

        final EditText gonderenInputView = findViewById(id.gonderenInputView);
        final EditText aliciInputView = findViewById(id.aliciInputView);
        final EditText konuInputView = findViewById(id.konuInputView);
        final EditText iletiInputView = findViewById(id.iletiInputView);
        final ImageButton saveButton = findViewById(id.saveButton);
        final ImageButton dontSaveButton = findViewById(id.dontSaveButton);


        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (gonderenInputView.getText().toString().length() != 0){
                    Intent intent = new Intent();
                    intent.putExtra(MainActivity.TAG, gonderenInputView.getText().toString());
                    setResult(RESULT_OK, intent);
                    DetailActivity.this.finish();   //destroy method
                }
                if (aliciInputView.getText().toString().length() != 0){
                    Intent intent = new Intent();
                    intent.putExtra(MainActivity.TAG, aliciInputView.getText().toString());
                    setResult(RESULT_OK, intent);
                    DetailActivity.this.finish();   //destroy method
                }
                if (konuInputView.getText().toString().length() != 0){
                    Intent intent = new Intent();
                    intent.putExtra(MainActivity.TAG, konuInputView.getText().toString());
                    setResult(RESULT_OK, intent);
                    DetailActivity.this.finish();   //destroy method
                }
                if (iletiInputView.getText().toString().length() != 0){
                    Intent intent = new Intent();
                    intent.putExtra(MainActivity.TAG, iletiInputView.getText().toString());
                    setResult(RESULT_OK, intent);
                    DetailActivity.this.finish();   //destroy method
                }
            }
        });


        dontSaveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DetailActivity.this.finish();
            }
        });
    }
}