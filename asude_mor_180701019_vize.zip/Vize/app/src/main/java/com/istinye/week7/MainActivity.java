package com.istinye.week7;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    public static final String TAG = "MainActivity";
    SearchView searchView;
    private CustomAdapter myListAdapter;
    private ListView myListView;
    //    private String[] listData = {"Google Maps Timeline", "Google Maps Timeline", "Google Maps Timeline", "Google Maps Timeline", "Google Photos"};
    private String[] listData = {};

    private String[] listData2 = {"Test YK, Mart ayı özetiniz", "Test YK, Şubat ayı özetiniz",
            "Test YK, Ocak ayı özetiniz", "Test YK, 2020 yılına ait güncellemeler", "Google fotoğraflar depertmanı"};
//    private String[] listData2 = {};

    private String[] listData3 = {"Bu zaman çizelgesi e-postası,gittiğiniz yeri", "Bu zaman çizelgesi e-postası,gittiğiniz yeri",
            "Bu zaman çizelgesi e-postası,gittiğiniz yeri", "COVID-19 nedeniyle 2020 yılında dünyada", "Merhaba Test YK, Google"};
//    private String[] listData3 = {};
//    ArrayAdapter<String> arrayAdapter;

    private List<String> list = new ArrayList<String>();
    public static final int DetailActivityRequestCode = 123;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        for (String name : listData) {
            list.add(name);
        }

        myListView = findViewById(R.id.myListView);
        if (myListView == null) Log.e(TAG, "List view is not initialized.");


        myListAdapter = new CustomAdapter(getApplicationContext(), list);
        //        arrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,listData);

        myListView.setAdapter(myListAdapter);
        myListAdapter.notifyDataSetChanged();   //listeyi gunceller.

        myListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(getApplicationContext(), list.get(position), Toast.LENGTH_SHORT).show();
            }
        });

        final Button newRecord = findViewById(R.id.new_record_button);
        newRecord.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), DetailActivity.class);
                startActivityForResult(intent, DetailActivityRequestCode); //bir girdi alacak
            }
        });
    }


//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        getMenuInflater().inflate(R.menu.my_menu, menu);
//        MenuItem menuItem = menu.findItem(R.id.search_icon);
//        SearchView searchView = (SearchView) menuItem.getActionView();
//        searchView.setQueryHint("Postalarda Arama Yapın");
//
//        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
//            @Override
//            public boolean onQueryTextSubmit(String query) {
//                return false;
//            }
//
//            @Override
//            public boolean onQueryTextChange(String newText) {
//                arrayAdapter.getFilter().filter(newText);
//                return true;
//            }
//        });
//
//        return super.onCreateOptionsMenu(menu);
//    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == DetailActivityRequestCode) { //came from Detail Activity
            if (resultCode == RESULT_OK) {
                if (data != null) {
                    list.add(data.getStringExtra(MainActivity.TAG));
                    myListAdapter.setList(list);
                    Toast.makeText(getApplicationContext(), "New record added.", Toast.LENGTH_SHORT).show();
                    myListAdapter.notifyDataSetChanged();
                }
            }
        }
        if (resultCode == RESULT_CANCELED){
            Toast.makeText(getApplicationContext(), "No new record.", Toast.LENGTH_SHORT).show();
        }
    }
}