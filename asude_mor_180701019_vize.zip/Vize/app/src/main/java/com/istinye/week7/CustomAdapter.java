package com.istinye.week7;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class CustomAdapter extends BaseAdapter {

    private static final String TAG = "CustomAdapter";
    private Context context;
    private List<String> listData;
    private List<String> listData2;
    private List<String> listData3;

    public CustomAdapter(Context context, List<String> listData){
        if (context == null){
            Log.e(TAG,"Context is null.");
            throw new IllegalArgumentException("Context can not be null.");
        }
        this.context = context;
        this.listData = listData;
    }

    @Override
    public int getCount() {
        if (listData == null) return 0;
        return listData.size();
    }

    @Override
    public Object getItem(int position) {
        return listData != null ? listData.get(position) : null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @SuppressLint("SimpleDateFormat")
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder = null;

        if (convertView == null){   //First initialization
            LayoutInflater layoutInflater = LayoutInflater.from(context);
            convertView = layoutInflater.inflate(R.layout.single_item_layout, parent, false);
            viewHolder = new ViewHolder(convertView);
            convertView.setTag(viewHolder);
            Log.d(TAG, "Single Item Layout Inflated " + position + "th");
        }else {
            //Second turn
            viewHolder = (ViewHolder) convertView.getTag();
        }

        if (position%2 == 0){
            convertView.setBackgroundColor(context.getResources().getColor((R.color.colorTurkuaz)));
        } else {
            convertView.setBackgroundColor(context.getResources().getColor((R.color.white)));
        }

        String date = new SimpleDateFormat("dd/MM/y", Locale.getDefault()).format(new Date());
        viewHolder.anaKonuTextView.setText(listData.get(position));
        viewHolder.tarihTextView.setText(date);
//        viewHolder.ozetTextView.setText(listData2.get(position));
//        viewHolder.aciklamaTextView.setText(listData3.get(position));

        Log.d(TAG, "getView is called by: " + position + "th");
        return convertView;
    }

    public void setList(List<String> list) {
        this.listData = list;
    }

    private class ViewHolder{
        public TextView anaKonuTextView;
        public TextView tarihTextView;
        public TextView ozetTextView;
        public TextView aciklamaTextView;

        public ViewHolder (View view) {
            anaKonuTextView = (TextView) view.findViewById(R.id.anaKonuTextView);
            tarihTextView = (TextView) view.findViewById(R.id.tarihTextView);
            ozetTextView = (TextView) view.findViewById(R.id.ozetTextView);
            aciklamaTextView = (TextView) view.findViewById(R.id.aciklamaTextView);
        }
    }
}