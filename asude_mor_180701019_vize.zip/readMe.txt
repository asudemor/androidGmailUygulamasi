Asude MOR
180701019
Yazılım Mühendisliği
3. Sınıf

-> Arama çubuğu kodlarını yazdım ama bir yerde hata verdiği için yorum satırına aldım.
-> TextView ile yaptığım için girilen 2 veriyi ekranda gösteremedim.
-> Verileri almak için Recycle kullanılabilirdi ama tam anlayamadığım için TextView de
yapmayı denedim.

-> Boş yıldıza basıldığında dolu yıldızın gelmesi için kodu yazdım ama hangi dosyaya
koyacağımdan emin olamadım.

        final ImageButton starButton = (ImageButton) findViewById(R.id.starButton);

        starButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                starButton.setImageResource(R.drawable.click_star);
            }
        });

-> Listeleri en başta boş olarak verdim. Listdata = {}